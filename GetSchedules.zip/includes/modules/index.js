import GetSchedules from './GetSchedules/GetSchedules';

export default [GetSchedules];
