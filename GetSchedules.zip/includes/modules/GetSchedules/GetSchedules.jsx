// External Dependencies
import React, { Component } from 'react';

class GetSchedules extends Component {

  static slug = 'get_schedules';

  render() {
    return "";
  }
}

export default GetSchedules;
